import java.io.IOException;
import static java.awt.event.KeyEvent.*;
import java.util.Arrays;

class ArtMNIST {

    public static void main(String[] args) {

        /* Сохраняем время запуска программы */
        long programStartTime = System.currentTimeMillis();


        try {

            /* создаём экземпляр считывателя базы данных цифр MNIST */
            MNISTReader mnistReader = new MNISTReader("../../mnist/data");

            /* теперь создаём экзмепляр нейронную сеть */
            NetworkOne network = new NetworkOne(28 * 28, /* Количество входных нейронов */
                                               new int[] {30, 10} /* Первый и второй (последний) слои */);

            /* устанавливаем набор данных обучения */
            network.setTrainingSet(mnistReader.trainImagesArr, mnistReader.trainBinaryLabels);

            



            ArtConsole console = new ArtConsole();
            int keyCode = 0;


            /* инициализируем параметры обучения */
            network.LEARNING_RATE = 0.001;
            network.DELTA_W = 0.01;
            network.randomWeightAdditionRange = 1;

            
            Sys.clearScreen();
            double error = 0;

            boolean backpropagationAllowed = true;
            int numberOfBackpropCycles = 50;

            boolean randomWalkAllowed = false;
            int numberOfRandomWalkCycles = 20;

            int miniBatchSize = 10;

            
            while (true) {
                console.clearScreen();
                int randomRange = (int)(Math.random() * 0);
                network.setCurrentMiniBatchRange(randomRange , randomRange + miniBatchSize - 1);
                error = network.getMeanSquareError();
                System.err.println(error);
                console.println("Error " + error);

                

                long cycleStartTime = System.currentTimeMillis();
 
                for (int i=0; i + miniBatchSize - 1 <= mnistReader.numberOfTrainingImages; i += miniBatchSize) {

                    /* Устанавливаем границы мини-пакета в цикле по тренировочным данным */
                    network.setCurrentMiniBatchRange(i, i + miniBatchSize - 1);

                    /* Минимизируем функцию ошибки на данном мини-пакете */
                    network.teachWithBackpropagation(1);

                    if (i % 5000 == 0) {
                        console.println("" + (100 * i / mnistReader.numberOfTrainingImages) + "%");
                    }
                  
                    
                }

                Sys.print("Time spent on the training cycle: " + (System.currentTimeMillis() - cycleStartTime) + " ms");

                
                
            }

            /*
            System.out.println("Bye! See you soon!");
            System.exit(0);
            */



       } /* Выше - если не было ошибки с открытием базы данных с цифрами MNIST */

       catch (IOException e) {
           System.out.println("Error opening MNIST data base! Exiting.");
       }
    }

}

