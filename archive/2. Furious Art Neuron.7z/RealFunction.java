public interface RealFunction {
    public double function(double arg[]);
}