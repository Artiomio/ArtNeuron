import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JPanel;

class Graphica extends JPanel{

    public BufferedImage canvas;
    public JFrame graphicaWindow;
    

    public void putPixel(int x, int y, Color color){
        canvas.setRGB(x, y, color.getRGB());
    }

    public void putPixel(int x, int y, int color){
        canvas.setRGB(x, y, color);
    }

    public void putPixel(int x, int y, int r, int g, int b){
        canvas.setRGB(x, y, (r << 16) + (g << 8) + b);
    }


    public void paintComponent(Graphics g) {
        // super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.drawImage(canvas, null, null);
    }

    
    public void setMyCanvas(BufferedImage myCanvas){
        canvas = myCanvas;
    }
   
    
    public Dimension getPreferredSize() {
        return new Dimension(canvas.getWidth(), canvas.getHeight());
   }
    
    

    public Graphica(int width, int height) {
        canvas = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        graphicaWindow = new JFrame();
        graphicaWindow.add(this);
        graphicaWindow.pack();
        graphicaWindow.setVisible(true);
        graphicaWindow.setResizable(false);
        graphicaWindow.setSize(width, height);
        graphicaWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
    }


}
    


