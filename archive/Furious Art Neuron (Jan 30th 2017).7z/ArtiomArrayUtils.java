class ArtiomArrayUtils {
	public static double[][][] empty3DArrayLike(double[][][] src) {
		double[][][] dest = new double[src.length][][];
		for (int i=0; i < src.length; i++)
			dest[i] = empty2DArrayLike(src[i]);
		
		return dest;
	}


	public static double[][] empty2DArrayLike(double[][] src) {
		double[][] dest = new double[src.length][];
		for (int i=0;  i < src.length; i++) {
			dest[i] = new double[src[i].length];
		}

		return dest;
	}


	public static void zeroFill3DArray(double[][][] arr) {
		for (int i=0;  i < arr.length; i++) 
			for (int j=0;  j < arr[i].length; j++) 
				for (int k=0;  k < arr[i][j].length; k++)
					arr[i][j][k] =	0;	

	}


	public static void FromArraySubtractArrayTimesAlpha(double[][][] arr1, double[][][] arr2, double alpha) {
		for (int i=0;  i < arr1.length; i++) 
			for (int j=0;  j < arr1[i].length; j++) 
				for (int k=0;  k < arr1[i][j].length; k++)
					arr1[i][j][k] -= alpha * arr2[i][j][k];
	}

	/**
	 * Print a 3D array of a given type
	 * @param a - array to print
	 * @param labels[] - a String array containing dimensions text annotations, e.g. labels = {"Z", "Y", "X"} or {"Layer", "Neuron", "Weight"} 
	 */
	public static void print3DArray(double[][][] a, String[] labels) {
		for (int i=0;  i < a.length; i++) {
				System.out.println(labels[0] + " " + i + " :");
				for (int j=0;  j < a[i].length; j++){ 
					System.out.println("    " + labels[1] + " " + j + " :");
					for (int k=0;  k < a[i][j].length; k++){
						System.out.printf("        %s %d  :  %.7f\n", labels[2], k, a[i][j][k]);
				}
			}
		}	
	}

}