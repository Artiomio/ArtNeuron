import java.io.IOException;
class ArtMNIST {
    public static void main(String[] args) {

        /* Сохраняем время запуска программы */
        long programStartTime = System.currentTimeMillis();

        try {

            /* создаём экземпляр считывателя базы данных цифр MNIST */
            MNISTReader mnistReader = new MNISTReader("../../mnist/data");

            /* теперь создаём экзмепляр нейронную сеть */
            NetworkOne network = new NetworkOne(28 * 28, /* Количество входных нейронов */
                                               new int[] {30, 10} /* Первый и второй (последний) слои */);

            /* устанавливаем набор данных обучения */
            network.setTrainingSet(mnistReader.trainImagesArr, mnistReader.trainBinaryLabels);

            





            /* инициализируем параметры обучения */
            network.LEARNING_RATE = 0.1;
            network.DELTA_W = 0.01;
            network.randomWeightAdditionRange = 1;

            while (true) {             
                System.out.println("Time elapsed: " + (System.currentTimeMillis() - programStartTime) / 1000 + " seconds");
                
                /* Устанавливаем границы мини-пакета */
                network.setCurrentMiniBatchRange(0, 1000);

                network.teachWithBackpropagation(10);
                network.teachByShakingWeights(20);
                
                
                double error = network.getMeanSquareError();
                Sys.clearScreen();
                System.out.println(error);
            }





       } /* Выше - если не было ошибки с открытием базы данных с цифрами MNIST */

       catch (IOException e) {
           System.out.println("Error opening MNIST data base! Exiting.");
       }
    }

}
