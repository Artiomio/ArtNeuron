class ArtiomArrayUtils {
	public static double[][][] empty3DArrayLike(double[][][] src) {
		double[][][] dest = new double[src.length][][];
		for (int i=0; i < src.length; i++)
			dest[i] = empty2DArrayLike(src[i]);
		
		return dest;
	}


	public static double[][] empty2DArrayLike(double[][] src) {
		double[][] dest = new double[src.length][];
		for (int i=0;  i < src.length; i++) {
			dest[i] = new double[src[i].length];
		}

		return dest;
	}


	public static void zeroFill3DArray(double[][][] arr) {
		for (int i=0;  i < arr.length; i++) 
			for (int j=0;  j < arr[i].length; j++) 
				for (int k=0;  k < arr[i][j].length; k++)
					arr[i][j][k] =	0;	

	}


	public static void FromArraySubtractArrayTimesAlpha(double[][][] arr1, double[][][] arr2, double alpha) {
		for (int i=0;  i < arr1.length; i++) 
			for (int j=0;  j < arr1[i].length; j++) 
				for (int k=0;  k < arr1[i][j].length; k++)
					arr1[i][j][k] -= alpha * arr2[i][j][k];
	}
}