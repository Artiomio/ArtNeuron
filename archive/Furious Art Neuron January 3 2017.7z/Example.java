import java.awt.Color;

import java.awt.image.BufferedImage;

public class Example {
    public static void main(String[] param) {
       Graphica gr = new Graphica (400,400);     
       int x,y;
       for (int i=1; i<1000; i++){
       		x=(int)(200*Math.random());
       		y=(int)(200*Math.random());
       		gr.putPixel(x,y, Color.RED);
       }	



        BufferedImage myCanvas = new BufferedImage(1500, 1500, BufferedImage.TYPE_INT_RGB);

        long startTime;
        gr.setMyCanvas(myCanvas);               
        long tick = 0;
        int color;
        while (true) {
            startTime = System.currentTimeMillis();               
            tick++; 
            for (y = 0; y < 400; y++){
                for (x = 0; x<400; x++) {
                    color = (((int)1) << 16) + ((int)( (256*Math.random())) << 8)  + (int)(256*Math.random());
                    myCanvas.setRGB(x, y, color);// Color.RED.getRGB());
                }
            }
//            System.out.println("Ready!");
//            System.out.println(System.currentTimeMillis() - startTime);

            try {
                    Thread.sleep(10);

            } catch(Exception e) {}
//            System.out.println("Hello!");
            gr.repaint();
        }
    }
}