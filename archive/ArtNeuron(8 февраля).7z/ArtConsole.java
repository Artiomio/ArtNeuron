import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.text.DefaultCaret;

public class ArtConsole implements KeyListener {
    JTextArea textArea;
    
    public void keyTyped(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }
    
    public JFrame keyboardReadingFrame;

    public volatile boolean keyPressed = false;
    public int keyCode;
    
 
    public int getKeyCode() {
        return keyCode; 

    }

    public void keyPressed(KeyEvent e) {
        this.keyPressed = true; 
        this.keyCode = e.getKeyCode();
    }


  
    public void clearKey() {
        keyPressed = false;
    }

    public ArtConsole() {
        keyboardReadingFrame = new JFrame();
        keyboardReadingFrame.setVisible(true);
        keyboardReadingFrame.setSize(300, 500);
        keyboardReadingFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        keyboardReadingFrame.addKeyListener(this);

        textArea = new JTextArea("Welcome!\n", 30, 80);

        textArea.setFont(new Font("monospaced", Font.PLAIN, 15));
        textArea.setFont(textArea.getFont().deriveFont(17f));

        textArea.setBackground(new Color(0, 0, 0));
        textArea.setForeground(new Color(0, 255, 0));
        textArea.addKeyListener(this);
        textArea.setEditable(false);

        keyboardReadingFrame.add(textArea);

        keyboardReadingFrame.pack();

    }

    public void print(String s) {
        textArea.append(s);
    }

    public void println(String s) {
        textArea.append(s + "\n");
    }


    public void print(int s) {
        textArea.append("" + s);
    }

    public void println(int s) {
        textArea.append("" + s + "\n");
    }

    public void print(double s) {
        textArea.append("" + s);
    }

    public void println(double s) {
        textArea.append("" + s + "\n");
    }










    public void clearScreen() {
        textArea.setText(null);
    }



    public static void main(String[] args) {
        ArtConsole keyb = new ArtConsole();

        while (true) {
            if (keyb.keyPressed) {
               keyb.clearKey();
               System.out.println("You pressed a key. Code: " + keyb.keyCode);
               keyb.println("You pressed a key. Code: " + keyb.keyCode);
            }
            
        }
    }

}