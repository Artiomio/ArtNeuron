class ArtiomArrayUtils {
	public static double[][][] empty3DArrayLike(double[][][] src) {
		double[][][] dest = new double[src.length][][];
		for (int i=0; i < src.length; i++)
			dest[i] = empty2DArrayLike(src[i]);
		
		return dest;
	}


	public static double[][] empty2DArrayLike(double[][] src) {
		double[][] dest = new double[src.length][];
		for (int i=0;  i < src.length; i++) {
			dest[i] = new double[src[i].length];
		}

		return dest;
	}

}