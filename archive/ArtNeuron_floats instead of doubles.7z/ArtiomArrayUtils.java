import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;


class ArtiomArrayUtils {
    public static float[][][] empty3DArrayLike(float[][][] src) {
        float[][][] dest = new float[src.length][][];
        for (int i=0; i < src.length; i++)
            dest[i] = empty2DArrayLike(src[i]);
        
        return dest;
    }


    public static float[][] empty2DArrayLike(float[][] src) {
        float[][] dest = new float[src.length][];
        for (int i=0;  i < src.length; i++) {
            dest[i] = new float[src[i].length];
        }

        return dest;
    }


    public static void zeroFill3DArray(float[][][] arr) {
        for (int i=0;  i < arr.length; i++) 
            for (int j=0;  j < arr[i].length; j++) 
                for (int k=0;  k < arr[i][j].length; k++)
                    arr[i][j][k] =  0;  

    }


    public static void multiplyArrayByScalar(float[][][] arr, float scalar) {
        for (int i=0;  i < arr.length; i++) 
            for (int j=0;  j < arr[i].length; j++) 
                for (int k=0;  k < arr[i][j].length; k++)
                    arr[i][j][k] = arr[i][j][k] * scalar ;  

    }



    public static void FromArraySubtractArrayTimesAlpha(float[][][] arr1, float[][][] arr2, float alpha) {
        for (int i=0;  i < arr1.length; i++) 
            for (int j=0;  j < arr1[i].length; j++) 
                for (int k=0;  k < arr1[i][j].length; k++)
                    arr1[i][j][k] -= alpha * arr2[i][j][k];
    }

    /**
     * Print a 3D array 
     * @param a - array to print
     * @param labels[] - a String array containing dimensions text annotations, e.g. labels = {"Z", "Y", "X"} or {"Layer", "Neuron", "Weight"} 
     */
    public static void print3DArray(float[][][] a, String[] labels) {
        for (int i=0;  i < a.length; i++) {
                System.out.println(labels[0] + " " + i + " :");
                for (int j=0;  j < a[i].length; j++){ 
                    System.out.println("    " + labels[1] + " " + j + " :");
                    for (int k=0;  k < a[i][j].length; k++){
                        System.out.printf("        %s %d  :  %.7f\n", labels[2], k, a[i][j][k]);
                }
            }
        }   
    }



    public static int maxIndexInArray(float[] a) {
        float max = a[0];
        int maxIndex = 0;
        for (int i=1; i < a.length; i++) {
            if (max < a[i]) {
                max = a[i];
                maxIndex = i;
            }
        }
        return maxIndex;
    }




    public static float maxValueInArray(float[] a) {
        float max = a[0];
        int maxIndex = 0;
        for (int i=1; i < a.length; i++) {
            if (max < a[i]) {
                max = a[i];
                maxIndex = i;
            }
        }
        return max;
    }

    public static int closestToOneIndex(float[] a) {
        float closestDiff = Math.abs(a[0] - 1);
        int closestIndex = 0;
        for (int i=1; i < a.length; i++) {
            float currentDiff = Math.abs(a[i] - 1);    
            if (closestDiff > currentDiff) {
                closestDiff = currentDiff;
                closestIndex = i;
            }
        }
        return closestIndex;
    }


    public static float abs(float[][][] a) {
        float s = 0;
        for (float[][] l : a) {
            for (float[] n : l) {
                for (float w : n) {
                    s += w * w;
                }
            }
        }
        return (float)(Math.sqrt(s));
    }
    
    public static void print2DArray(int[][] a) {
        String[] labels = {"Row", "Column"};
        for (int j=0;  j < a.length; j++) { 
            System.out.println("    Row " + j + " :");
            for (int k=0;  k < a[j].length; k++) {
                System.out.printf("        %s %d  :  %d\n", "Column", k, a[j][k]);
            }
        }
            
    }

    public static void serialize3DArray(float[][][] arr, String filename) {
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(filename));
            os.writeObject(arr);
        }
        catch(IOException e) {
            System.out.println("Error while trying to serialize array!");
            throw new ArrayIndexOutOfBoundsException();
        }
        
    }

    public static float[][][] loadSerialized3DArray(String filename) {
            ObjectInputStream is;
            float[][][] arr = null;
            
            try {
                is = new ObjectInputStream(new FileInputStream(filename));
                try {
                    arr = (float[][][]) is.readObject();
                }
                catch(Exception e) {
                    System.out.println("Error while deserializing array!");
                }

            }
            catch(IOException e) {
                System.out.println("Wow there's something wrong with the file!");
            }

            return arr;

    }




    

    public static String convert3DArrayToPythonStyle(float[][][] a) {
        StringBuffer arrString = new StringBuffer("[");
        for (int i=0;  i < a.length; i++) {
            arrString.append("[");
            for (int j=0;  j < a[i].length; j++){ 
                arrString.append("[");
                for (int k=0;  k < a[i][j].length; k++){
                    arrString.append("" + a[i][j][k]);
                    if (k != a[i][j].length - 1) arrString.append(", ");
                }
                arrString.append("]");
                if (j != a[i].length - 1) arrString.append(", ");
            }
            arrString.append("]");
            if (i != a.length - 1) arrString.append(", ");
        }   
        arrString.append("]");
        return arrString.toString();
        
    }

    public static void write3DArrayToFilePythonStyle(float[][][] a, String filename) {
        try {
            String text = convert3DArrayToPythonStyle(a);
            Files.write(Paths.get(filename), text.getBytes());
        }
        catch (Exception e) {
            System.out.println("Something went wrong!");
        }
        
        

    }



}