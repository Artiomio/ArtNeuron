import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.Color;

public class KeyboardReadingWindow implements KeyListener {
    JTextArea textArea;
    
    public void keyTyped(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }
    
    public JFrame keyboardReadingFrame;

    public volatile boolean keyPressed = false;
    public int keyCode;
    
 
    public int getKeyCode() {
        return keyCode; 

    }

    public void keyPressed(KeyEvent e) {
        this.keyPressed = true; 
        this.keyCode = e.getKeyCode();
    }


  
    public void clearKey() {
        keyPressed = false;
    }

    public KeyboardReadingWindow() {
        keyboardReadingFrame = new JFrame();
        keyboardReadingFrame.setVisible(true);
        keyboardReadingFrame.setSize(800, 500);
        keyboardReadingFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        keyboardReadingFrame.addKeyListener(this);

        textArea = new JTextArea("Welcome!\n", 30, 130);
//        textArea.setFont(new Font("monospaced", Font.PLAIN, 15));
        textArea.setBackground(new Color(0, 0, 0));
        textArea.setForeground(new Color(0, 255, 0));
        textArea.addKeyListener(this);
        textArea.setEditable(false);

        keyboardReadingFrame.add(textArea);

        keyboardReadingFrame.pack();

    }

    public void print(String s) {
        textArea.append(s);
    }

    public void println(String s) {
        textArea.append(s + "\n");
    }

    public void clearScreen() {
        textArea.setText(null);
    }


    public static void main(String[] args) {
        KeyboardReadingWindow keyb = new KeyboardReadingWindow();

        while (true) {
            if (keyb.keyPressed) {
               keyb.clearKey();
               System.out.println("You pressed a key. Code: " + keyb.keyCode);
               keyb.println("You pressed a key. Code: " + keyb.keyCode);
            }
            
        }
    }

}