import java.io.IOException;
import static java.awt.event.KeyEvent.*;
import java.util.Arrays;

class ArtMNIST {

    public static void main(String[] args) {

        /* Сохраняем время запуска программы */
        long programStartTime = System.currentTimeMillis();


        try {

            /* создаём экземпляр считывателя базы данных цифр MNIST */
            MNISTReader mnistReader = new MNISTReader("../../mnist/data");

            /* теперь создаём экзмепляр нейронную сеть */
            NetworkOne network = new NetworkOne(28 * 28, /* Количество входных нейронов */
                                               new int[] {100, 100, 10} /* Первый и второй (последний) слои */);

            /* устанавливаем набор данных обучения */
            network.setTrainingSet(mnistReader.trainImagesArr, mnistReader.trainBinaryLabels);

            



            KeyboardReadingWindow keyb = new KeyboardReadingWindow();
            int keyCode = 0;


            /* инициализируем параметры обучения */
            network.LEARNING_RATE = 0.01;
            network.DELTA_W = 0.01;
            network.randomWeightAdditionRange = 1;

            /* Основной цикл обучения */

            Sys.clearScreen();
            double error = 0;

            boolean backpropagationAllowed = true;
            int numberOfBackpropCycles = 50;

            boolean randomWalkAllowed = false;
            int numberOfRandomWalkCycles = 20;

            int miniBatchSize = 50;



            while (keyCode != VK_ESCAPE && keyCode != VK_Q) {
                
                if (keyb.keyPressed) { /* Обработка нажатий клавиш */
                    keyb.clearKey();
                    keyCode = keyb.keyCode;

                    if (keyCode == VK_ADD) {
                        network.LEARNING_RATE *= 1.1;
                        System.out.println("Increasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }

                    if (keyCode == VK_SUBTRACT) {
                        network.LEARNING_RATE /= 1.1;
                        System.out.println("Decreasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }

                    if (keyCode == VK_MULTIPLY) {
                        network.LEARNING_RATE *= 10;
                        System.out.println("Increasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }

                    if (keyCode == VK_DIVIDE) {
                        network.LEARNING_RATE /= 10;
                        System.out.println("Decreasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }


                    if (keyCode == VK_PAGE_UP) {
                        network.randomWeightAdditionRange *= 2;
                        System.out.println("Increasing Random step max size! Now it is " + network.randomWeightAdditionRange);
                    }

                    if (keyCode == VK_PAGE_DOWN) {
                        network.randomWeightAdditionRange /= 2;
                        System.out.println("Decreasing random step max size! Now it is " + network.randomWeightAdditionRange);
                    }

                    
                    if (keyCode == VK_R) {
                        System.out.println("Reinitializing weights");
                        network.initializeWeightsWithRandomNumbers();
                        programStartTime = System.currentTimeMillis();
                    }

                    if (keyCode == VK_B)
                        backpropagationAllowed = !backpropagationAllowed;

                    if (keyCode == VK_F)
                        randomWalkAllowed = !randomWalkAllowed;




                } /* Обработка клавиш */



                /* Устанавливаем границы мини-пакета */                
                network.setCurrentMiniBatchRange(0, miniBatchSize);

                /* Обучение обратным распространением */
                long timeBackpropStart = System.currentTimeMillis();                         /* Засекаем время         */
                if (backpropagationAllowed)
                    network.teachWithBackpropagation(numberOfBackpropCycles);                /* работы backpropagation */
                long timeSpentOnBackprop = System.currentTimeMillis() - timeBackpropStart;


                /* Обучением случайным блужданием и фантазёрством */
                long timeRandomWalkStart = System.currentTimeMillis();        /* Засекаем время */
                if (randomWalkAllowed)
                    network.teachByShakingWeights(numberOfRandomWalkCycles);  /* случайного блуждания */
                long timeSpentOnRandomWalk = System.currentTimeMillis() - timeRandomWalkStart;


                Sys.clearScreen(); /* Стираем с экрана */


                long timeMeanSquareErrorCalculationStart = System.currentTimeMillis(); /* Засекаем время вычисления простой                 */
                error = network.getMeanSquareError();                                  /*  среднеквадратичной ошибки на текущем мини-пакете */
                long timeSpentOnErrorCalculation = System.currentTimeMillis() - timeMeanSquareErrorCalculationStart;

                System.out.println("Mean square error: " + error);
                System.err.println(error); /* Перенаправляем в stderr */
                


                System.out.println("Time elapsed: " + (System.currentTimeMillis() - programStartTime) / 1000 + " seconds");
                System.out.println("Learning with:\n    Learning rate: " + network.LEARNING_RATE + 
                                   "\n    Random max step: " + network.randomWeightAdditionRange +
                                   "\nMini-batch size: " + miniBatchSize + "\n");
                System.out.println("Backpropagation: " + (backpropagationAllowed? "ON " : "OFF") + "\nRandom walk: " + (randomWalkAllowed? "ON" : "OFF"));

                System.out.println("\nNumber of backpropagation SGD cycles: " + numberOfBackpropCycles);
                System.out.println("Number of random fantasizing cycles: " + numberOfRandomWalkCycles);


                System.out.println("\nBackpropagation SGD took: " + timeSpentOnBackprop + " ms");
                System.out.println("Random walk took: " + timeSpentOnRandomWalk + " ms");
                System.out.println("Error calculation took:" + timeSpentOnErrorCalculation + " ms");

                for (int i=0; i<=10; i++) {
                    
                }

                int n = 212;
                network.feedForward(mnistReader.trainImagesArr[n]);

                System.out.println(Arrays.toString(network.output));
                System.out.println(ArtiomArrayUtils.maxIndexInArray(network.output));
                System.out.println("Digit is known to be " + mnistReader.trainingDigit[n]);




            }



            System.out.println("Bye! See you soon!");
            System.exit(0);



       } /* Выше - если не было ошибки с открытием базы данных с цифрами MNIST */

       catch (IOException e) {
           System.out.println("Error opening MNIST data base! Exiting.");
       }
    }

}

